"""Persistent owner-managed media used by the /start welcome screen."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import config

STORE = config.BASE_DIR / "data" / "start_media.json"
DEFAULT: dict[str, Any] = {"main": None, "sticker": None, "voice": None}


def load() -> dict[str, Any]:
    try:
        value = json.loads(STORE.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            return {**DEFAULT, **value}
    except (OSError, json.JSONDecodeError):
        pass
    return DEFAULT.copy()


def save(data: dict[str, Any]) -> None:
    STORE.parent.mkdir(parents=True, exist_ok=True)
    temp = STORE.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(STORE)


def set_item(key: str, kind: str, file_id: str) -> None:
    data = load()
    data[key] = {"type": kind, "file_id": file_id}
    save(data)


def clear_item(key: str) -> None:
    data = load()
    data[key] = None
    save(data)


def is_owner(user_id: int | None) -> bool:
    return user_id is not None and user_id in config.SUDOERS
