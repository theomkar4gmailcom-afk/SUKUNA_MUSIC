"""/start, /help, /id"""

from __future__ import annotations

from pyrogram import filters
from pyrogram.types import Message

import config
from app.clients import bot
from app.utils import start_keyboard
from app.start_media import load

HELP_TEXT = """
**{bot} — commands**

**Playback**
• `{p}play <name/link>` — song ya video VC me play karo
• `{p}vplay <name/link>` — video ke saath play
• `{p}playlist <playlist link>` — pura playlist queue me
• `{p}search <name>` — top {n} results, button se choose karo
• `{p}play` (audio/video file ko reply karke) — Telegram file play

**Controls** (admins only)
• `{p}pause` / `{p}resume`
• `{p}skip` — next track
• `{p}end` — stop + clear queue + leave VC
• `{p}loop` — current track repeat on/off
• `{p}volume 1-200`

**Info**
• `{p}queue` — queue dekho
• `{p}current` — now playing + elapsed time

**Welcome media (owner only, private chat)**
• Reply to photo/video/GIF with `/setstartmedia`
• Reply to sticker with `/setstartsticker`
• Reply to voice/audio with `/setstartvoice`
• `/clearstartmedia main|sticker|voice|all`

**Setup:** assistant account ko group me add karo, phir group voice chat
start karke `/play` bhejo.
""".strip()


@bot.on_message(filters.command(["start"], prefixes=config.COMMAND_PREFIXES))
async def start_handler(client, message: Message) -> None:
    name = message.from_user.first_name if message.from_user else "there"
    text = (
        f"🔥 **Welcome {name}!**\\n\\n"
        f"Main **{config.BOT_NAME}** hoon — group voice chat me music play karta hoon.\\n\\n"
        f"➊ Bot aur assistant ko group me add karo\\n"
        f"➋ Group voice chat start karo\\n"
        f"➌ `{config.COMMAND_PREFIXES[0]}play <song name>` bhejo\\n\\n"
        f"Commands ke liye /help"
    )
    media = load()
    main_media = media.get("main")
    sent_main = False
    if main_media:
        kind, file_id = main_media.get("type"), main_media.get("file_id")
        try:
            if kind == "photo":
                await message.reply_photo(file_id, caption=text, reply_markup=start_keyboard())
            elif kind == "video":
                await message.reply_video(file_id, caption=text, reply_markup=start_keyboard())
            elif kind == "animation":
                await message.reply_animation(file_id, caption=text, reply_markup=start_keyboard())
            sent_main = True
        except Exception:
            sent_main = False
    if not sent_main and config.START_IMAGE:
        try:
            await message.reply_photo(config.START_IMAGE, caption=text, reply_markup=start_keyboard())
            sent_main = True
        except Exception:
            pass
    if not sent_main:
        await message.reply_text(text, reply_markup=start_keyboard())
    sticker = media.get("sticker")
    if sticker:
        try:
            await message.reply_sticker(sticker["file_id"])
        except Exception:
            pass
    voice = media.get("voice")
    if voice:
        try:
            if voice.get("type") == "audio":
                await message.reply_audio(voice["file_id"])
            else:
                await message.reply_voice(voice["file_id"])
        except Exception:
            pass


@bot.on_message(filters.command(["help"], prefixes=config.COMMAND_PREFIXES))
async def help_handler(client, message: Message) -> None:
    await message.reply_text(
        HELP_TEXT.format(
            bot=config.BOT_NAME,
            p=config.COMMAND_PREFIXES[0],
            n=config.SEARCH_LIMIT,
        )
    )


@bot.on_message(filters.command(["id", "chatid"], prefixes=config.COMMAND_PREFIXES))
async def id_handler(client, message: Message) -> None:
    await message.reply_text(
        f"**Chat id:** `{message.chat.id}`\n"
        f"**Your id:** `{message.from_user.id if message.from_user else '—'}`"
    )
