"""Owner-only commands to configure the /start photo/video/sticker/voice."""

from __future__ import annotations

from pyrogram import filters
from pyrogram.types import Message

import config
from app.clients import bot
from app.start_media import clear_item, is_owner, set_item


def _owner(message: Message) -> bool:
    return is_owner(message.from_user.id if message.from_user else None)


@bot.on_message(filters.command(["setstartmedia"], prefixes=config.COMMAND_PREFIXES) & filters.private)
async def set_start_media(client, message: Message) -> None:
    if not _owner(message):
        await message.reply_text("⛔ यह command सिर्फ bot owner चला सकता है।")
        return
    replied = message.reply_to_message
    if not replied:
        await message.reply_text("किसी Photo, Video या GIF पर reply करके /setstartmedia भेजो।")
        return
    media = replied.photo or replied.video or replied.animation
    if not media:
        await message.reply_text("❌ Reply में Photo, Video या GIF होना चाहिए।")
        return
    kind = "photo" if replied.photo else ("video" if replied.video else "animation")
    set_item("main", kind, media.file_id)
    await message.reply_text(f"✅ Start {kind} save हो गया। अब /start पर दिखेगा।")


@bot.on_message(filters.command(["setstartsticker"], prefixes=config.COMMAND_PREFIXES) & filters.private)
async def set_start_sticker(client, message: Message) -> None:
    if not _owner(message):
        await message.reply_text("⛔ यह command सिर्फ bot owner चला सकता है।")
        return
    replied = message.reply_to_message
    if not replied or not replied.sticker:
        await message.reply_text("Sticker पर reply करके /setstartsticker भेजो।")
        return
    set_item("sticker", "sticker", replied.sticker.file_id)
    await message.reply_text("✅ Welcome sticker save हो गया।")


@bot.on_message(filters.command(["setstartvoice"], prefixes=config.COMMAND_PREFIXES) & filters.private)
async def set_start_voice(client, message: Message) -> None:
    if not _owner(message):
        await message.reply_text("⛔ यह command सिर्फ bot owner चला सकता है।")
        return
    replied = message.reply_to_message
    media = (replied.voice or replied.audio) if replied else None
    if not media:
        await message.reply_text("Voice या audio message पर reply करके /setstartvoice भेजो।")
        return
    set_item("voice", "voice" if replied.voice else "audio", media.file_id)
    await message.reply_text("✅ Welcome voice/audio save हो गया।")


@bot.on_message(filters.command(["clearstartmedia"], prefixes=config.COMMAND_PREFIXES) & filters.private)
async def clear_start_media(client, message: Message) -> None:
    if not _owner(message):
        await message.reply_text("⛔ यह command सिर्फ bot owner चला सकता है।")
        return
    if len(message.command) < 2:
        await message.reply_text("Usage: /clearstartmedia main|sticker|voice|all")
        return
    target = message.command[1].lower()
    if target == "all":
        for key in ("main", "sticker", "voice"):
            clear_item(key)
    elif target in ("main", "sticker", "voice"):
        clear_item(target)
    else:
        await message.reply_text("❌ main, sticker, voice या all चुनो।")
        return
    await message.reply_text(f"✅ {target} media clear कर दिया।")
