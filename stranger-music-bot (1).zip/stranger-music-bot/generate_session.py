"""
Generate a Pyrogram string session for the ASSISTANT account.

    python generate_session.py

Login with a normal Telegram account (not the bot). That account will be the
one joining voice chats, so it must be a member of your group.
"""

from pyrogram import Client

print(
    "\n=== Stranger Music — assistant session generator ===\n"
    "Telegram API details: https://my.telegram.org/apps\n"
)

api_id = int(input("36107613: ").strip())
api_hash = input("003b71b3d1cfa636f4a2388867703035: ").strip()

with Client(
    name="assistant_session",
    api_id=api_id,
    api_hash=api_hash,
    in_memory=True,
) as app:
    print("\nBQCZzqEAHFTtx3IBtHsR55BWb3JCR-1ELZkrupGQBW7HH3SuOdNaOBBMRXDeJcLrKrRw9AAWwWKmhrG2p_QBM6HWQGzi8p1YcmUeu1ngdUKKwOf6piT6WuNFWkEs9mOGHUs8uvI3PnvaqpQlri4wJ6p3E650miH4d8G3Zyh7EvBcjlt4fjeEhjjdWZACwoBuHmjahczXjnFtlR8KwiMiRYIoP7Z8FwhMCUUcXEVywKt_JMulOvsFWEV2Fb2C6O6m0vUXV4J8y858lMaUS0N44ilGGCvTpbu8HegkqAW7NlIut0Bo2qQPAZYPX2fat9k9ia7S7SJV6IhEimmtu9v7E4mNuw2KdgAAAAIZLE2lAA (keep it secret!):\n")
    print(app.export_session_string())
    print("\nPaste it in .env as SESSION_STRING=...\n")
